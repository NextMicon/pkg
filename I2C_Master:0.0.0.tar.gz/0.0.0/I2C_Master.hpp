#pragma once
#include "cpu.hpp"
#include <stdint.h>

class I2C_Master {
};
