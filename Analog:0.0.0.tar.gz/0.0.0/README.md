# PWM

![](img/pwm.dio.svg)
