# Spectrogram

FFTをします。
