# GPIO

![](img/gpio.dio.svg)
